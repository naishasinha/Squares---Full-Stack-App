import * as assert from 'assert';
import { solid, split, toJson, fromJson, getSubtreeRoot, Path, replaceSubtree } from './square';
import { cons, nil } from './list';


describe('square', function() {

  it('toJson', function() {
    assert.deepEqual(toJson(solid("white")), "white");
    assert.deepEqual(toJson(solid("green")), "green");

    const s1 = split(solid("blue"), solid("orange"), solid("purple"), solid("white"));
    assert.deepEqual(toJson(s1),
      ["blue", "orange", "purple", "white"]);

    const s2 = split(s1, solid("green"), s1, solid("red"));
    assert.deepEqual(toJson(s2),
      [["blue", "orange", "purple", "white"], "green",
       ["blue", "orange", "purple", "white"], "red"]);

    const s3 = split(solid("green"), s1, solid("yellow"), s1);
    assert.deepEqual(toJson(s3),
      ["green", ["blue", "orange", "purple", "white"],
       "yellow", ["blue", "orange", "purple", "white"]]);
  });

  it('fromJson', function() {
    assert.deepEqual(fromJson("white"), solid("white"));
    assert.deepEqual(fromJson("green"), solid("green"));

    const s1 = split(solid("blue"), solid("orange"), solid("purple"), solid("white"));
    assert.deepEqual(fromJson(["blue", "orange", "purple", "white"]), s1);

    assert.deepEqual(
        fromJson([["blue", "orange", "purple", "white"], "green",
                 ["blue", "orange", "purple", "white"], "red"]),
        split(s1, solid("green"), s1, solid("red")));

    assert.deepEqual(
        fromJson(["green", ["blue", "orange", "purple", "white"],
                  "yellow", ["blue", "orange", "purple", "white"]]),
        split(solid("green"), s1, solid("yellow"), s1));
  });

 it('getSubtreeRoot', function() {
  // 0 recursive cases - base case (nil path)
  const s1 = split(solid("blue"), solid("orange"), solid("purple"), solid("white"));
  assert.deepEqual(getSubtreeRoot(s1, nil), split(solid("blue"), solid("orange"), solid("purple"), solid("white")));

  // 0 recursive cases - base case (solid square)
  const s2 = solid("blue");
  const p1: Path = cons("NW", nil);
  assert.throws(() => getSubtreeRoot(s2, p1), Error("Solid Square"));

  // 0 recursive cases - base case (solid square)
  const p3: Path = cons("SE", cons("NW", nil));
  assert.throws(() => getSubtreeRoot(s1, p3), Error("Solid Square"));

  // 1 recursive case
  assert.deepEqual(getSubtreeRoot(s1, p1), solid("blue"));
  const p2: Path = cons("SE", nil);

  // 1 recursive case
  assert.deepEqual(getSubtreeRoot(s1, p2), solid("white"));
  
  // 2+ recursive cases
  const multSq1 = split(split(solid("orange"), solid("white"), solid("orange"), solid("purple")), solid("blue"), solid("blue"), solid("blue"));
  const pathmultSq1: Path = cons("NW", cons("NW", nil));
  assert.deepEqual(getSubtreeRoot(multSq1, pathmultSq1), solid("orange"));

  // 2+ recursive cases
  const multSq2 = split(solid("purple"), 
                          split(split(solid("blue"), solid("blue"), solid("blue"), solid("blue")), solid("orange"), solid("white"), solid("purple")), 
                          solid("white"), 
                          solid("purple"));
  const pathMultSq2: Path = cons("NE", cons("NW", cons("SE", nil)));
  assert.deepEqual(getSubtreeRoot(multSq2, pathMultSq2), solid("blue"));


 });

 it('replaceSubtree', function() {
  // 0 recursive cases - base case (nil path)
  const s1 = solid("blue");
  const ns1 = solid("green");
  assert.deepEqual(replaceSubtree(s1, nil, ns1), solid("green"));

  // 0 recursive cases - base case (solid square)
  const p1: Path = cons("NW", nil);
  assert.throws(() => replaceSubtree(s1, p1, ns1), Error("Solid Square"));

  // 0 recursive cases - base case (solid square)
  const s2 = split(solid("blue"), solid("orange"), solid("purple"), solid("white"));
  const p3: Path = cons("SE", cons("NW", nil));
  assert.throws(() => replaceSubtree(s2, p3, ns1), Error("Solid Square"));

  // 1 recursive case
  const p2: Path = cons("SE", nil);
  assert.deepEqual(replaceSubtree(s2, p2, ns1),
  split(solid("blue"), solid("orange"), solid("purple"), solid("green"))
  );

  // 1 recursive case
  assert.deepEqual(replaceSubtree(s2, p1, ns1),
  split(solid("green"), solid("orange"), solid("purple"), solid("white"))
  );
  
  // 2+ recursive cases
  const s4 = split(solid("purple"), solid("purple"), solid("purple"), split(solid("orange"), solid("orange"), solid("orange"), solid("orange")));
  assert.deepEqual(replaceSubtree(s4, p3, ns1), 
      split(solid("purple"), solid("purple"), solid("purple"), split(solid("green"), solid("orange"), solid("orange"), solid("orange"))));

  // 2+ recursive cases
  const multSq2 = split(solid("purple"), 
                          split(split(solid("blue"), solid("blue"), solid("blue"), solid("blue")), solid("orange"), solid("white"), solid("purple")), 
                          solid("white"), 
                          solid("purple"));
  const pathMultSq2: Path = cons("NE", cons("NW", cons("SW", nil)));
  assert.deepEqual(replaceSubtree(multSq2, pathMultSq2, ns1), 
                    split(solid("purple"), 
                    split(split(solid("blue"), solid("blue"), solid("green"), solid("blue")), solid("orange"), solid("white"), solid("purple")), 
                    solid("white"), 
                    solid("purple")));


 });


});
