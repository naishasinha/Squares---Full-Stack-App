import React, { Component, ChangeEvent, MouseEvent } from "react";
import { Square, Path, getSubtreeRoot, Color, toColor, split, solid, replaceSubtree, Dir  } from './square';
import { SquareElem } from "./square_draw";
import { len, prefix, List, nil} from "./list";


type EditorProps = {
  /** Initial state of the file. */
  initialState: Square;
  onSave: (designData: Square) => void;
  onBack: () => void;
};


type EditorState = {
  /** The root square of all squares in the design */
  root: Square;

  /** Path to the square that is currently clicked on, if any */
  selected?: Path;

  opt: Color;
};


/** UI for editing the image. */
export class Editor extends Component<EditorProps, EditorState> {

  constructor(props: EditorProps) {
    super(props);

      this.state = { root: props.initialState, opt: "blue"};
  }

  render = (): JSX.Element => {
    // TODO: add some editing tools here

    return (
      <div>
        <SquareElem
          width={600}
          height={600}
          square={this.state.root}
          selected={this.state.selected}
          onClick={this.doSquareClick}
        ></SquareElem>

        <button onClick={this.doSplitClick}>Split</button>
        <button onClick={this.doMergeClick}>Merge</button>

        <select value = {this.state.opt} onChange={this.doColorChange}>
          <option value="white">White</option>
          <option value="red">Red</option>
          <option value="orange">Orange</option>
          <option value="yellow">Yellow</option>
          <option value="green">Green</option>
          <option value="blue">Blue</option>
          <option value="purple">Purple</option>
        </select>

        <button onClick = {this.doSaveClick}>Save</button>
        <button onClick = {this.doBackClick}>Back</button>

      </div>
    );

  };

  doSquareClick = (path: Path): void => {
    this.setState({ selected: path });
  }

  doSplitClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
    // TODO: implement
    // split that square into four parts

    const path: Path | undefined = this.state.selected;
  
    if (path !== undefined) {
  
      // Use getSubtreeRoot to get the root of the selected subtree
      const selectedRoot = getSubtreeRoot(this.state.root, path);
  
      // Create a new square representing the split
      if (selectedRoot.kind === "solid" && this.state.selected !== undefined) {
        const newSplitSquare = split(
          solid(selectedRoot.color), 
          solid(selectedRoot.color),
          solid(selectedRoot.color),
          solid(selectedRoot.color)
        );
      
        const finalSquare = replaceSubtree(this.state.root, this.state.selected, newSplitSquare);
    
        // Update the state with the new root
        this.setState({ root: finalSquare, selected: undefined });

      }

    }
  };

  doMergeClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
    // TODO: implement
    // Merge the square with its siblings, i.e., replace its parent with a single solid square of that color.
    if (this.state.selected !== undefined && this.state.selected !== nil) {
      // Get the path to the parent of the selected square
      const parentPath: List<Dir> = prefix(len(this.state.selected) - 1, this.state.selected);
  
      // Use getSubtreeRoot to get the root of the parent subtree
      const currentRoot = getSubtreeRoot(this.state.root, this.state.selected);
      const replaceSquare = replaceSubtree(this.state.root, parentPath, currentRoot);


      this.setState({root: replaceSquare, selected: undefined});
    }
  };

  doColorChange = (evt: ChangeEvent<HTMLSelectElement>): void => {
    // TODO: implement
    const newColor = toColor(evt.target.value);

    if (this.state.selected){
      const replacesquare = replaceSubtree(this.state.root, this.state.selected, solid(newColor));
      console.log(`Picked option: ${newColor}`);
      this.setState({root: replacesquare, selected: undefined});
    }

  };

  doSaveClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
    this.props.onSave(this.state.root);
  };

  doBackClick = (): void => {
    this.props.onBack();
  };
}
